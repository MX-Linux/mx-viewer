inline const QString VERSION {"26.10.1"};
